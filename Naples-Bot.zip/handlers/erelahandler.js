

module.exports = (client) => {
  //Create the client 
  require("./erela_events/creation")(client)
   //in there we are requireing the node_events + client and normal events
};

/**
* @INFO
* Bot Coded by Tomato#6966 | https://github.com/Tomato6966/discord-js-lavalink-Music-Bot-erela-js
* @INFO
* Work for Milrato Development | https://milrato.eu
* @INFO
* Please mention Him / Milrato Development, when using this Code!
* @INFO
*/
